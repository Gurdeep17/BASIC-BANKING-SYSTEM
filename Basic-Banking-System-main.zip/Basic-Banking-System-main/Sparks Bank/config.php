<?php

$server="localhost";
$username="root";
$password="";
$db="sparks_bank";

$conn = mysqli_connect($server,$username,$password,$db);

?>