# Basic-Banking-System
Web Development Intern at Sparks Foundation
Technologies used
-HTML
-CSS
-Mysql
-php
